import React from "react";
import './App.css';
import Header from "./Header/Header";
// import './styles/myStyle.css'

const App = () => {
    return (
        <div className="App">
            <div className="container">
                <main>
                    <Header/>

                </main>
            </div>
        </div>
    );
}

    export default App;
